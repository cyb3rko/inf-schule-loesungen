import greenfoot.*;
import java.util.Random;

 class Gegner extends Actor {
    Random random;
    int locationTimer;
    
    Gegner() {
        random = new Random();
        locationTimer = 1;
    }

    public void act() {
        locationTimer--;
        
        if (locationTimer == 0) {
            bewegenUndSchiessen();
            locationTimer = 120;
        }
    }
    
    void bewegenUndSchiessen() {
        setLocation(random.nextInt(1280), getY());
        getWorld().addObject(new Stachel(), getX(), 150);
    }
}