import greenfoot.*;
import javax.swing.JOptionPane;

class Spieler extends Actor {
    int punkte;
    int wartezeit;
    boolean richtung;

    Spieler() {
        richtung = true;
    }

    public void act() {
        if (isTouching(Stachel.class)) {
            JOptionPane.showMessageDialog(null, "Du hast " + punkte + " Punkte erreicht.");
            Greenfoot.stop();
        }
        
        getWorld().showText("Punktestand: " + punkte, 110, 30);
        tastenEingaben();
        wartezeit++;
        punkte++;
    }
    
    void tastenEingaben() {
        if (Greenfoot.isKeyDown("left")) {
            if (richtung) {
                getImage().mirrorHorizontally();
            }

            richtung = false;
            setLocation(getX() - 10, getY());
        }

        if (Greenfoot.isKeyDown("right")) {
            if (!richtung) {
                getImage().mirrorHorizontally();
            }

            richtung = true;
            setLocation(getX() + 10, getY());
        }

        if (Greenfoot.isKeyDown("space") && wartezeit > 20) {
            getWorld().addObject(new Pfeil(), getX(), 555);

            punkte -= 30;
            wartezeit = 0;
        }
    }
}