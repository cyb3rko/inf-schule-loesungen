import greenfoot.*;

class Stachel extends Actor {
    public void act() {
        if (!isAtEdge()) {
            setLocation(getX(), getY() + 10);
        } else {
            getWorld().removeObject(this);
        }
    }
}