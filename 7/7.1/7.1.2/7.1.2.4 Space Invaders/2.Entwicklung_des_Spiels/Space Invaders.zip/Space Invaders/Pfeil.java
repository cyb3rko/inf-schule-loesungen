import greenfoot.*;

class Pfeil extends Actor {
    public void act() {
        if (isTouching(Gegner.class)) {
            removeTouching(Gegner.class);
            getWorld().removeObject(this);
        } else if (!isAtEdge()) {
            setLocation(getX(), getY() - 10);
        } else {
            getWorld().removeObject(this);
        }
    }    
}