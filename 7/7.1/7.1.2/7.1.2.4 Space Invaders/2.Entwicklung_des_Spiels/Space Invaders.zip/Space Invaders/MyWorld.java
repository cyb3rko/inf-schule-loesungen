import greenfoot.*;
import java.util.Random;

public class MyWorld extends World {
    Random random;
    int speed;
    int speedTimer;
    int spawnTimer;

    public MyWorld() {    
        super(1280, 720, 1);
        random = new Random();
        speed = 50;
        Greenfoot.setSpeed(speed);
        speedTimer = 600;
        spawnTimer = 1;
        prepare();
    }
    
    void prepare() {
        addObject(new Spieler(), 640, 645);
    }
    
    public void act() {
        spawnGegner();
        speedManager();
    }
    
    void spawnGegner() {
        spawnTimer--;
        
        if (spawnTimer == 0) {
            addObject(new Gegner(), random.nextInt(1280), 50);
            spawnTimer = 100;
        }
    }
    
    void speedManager() {
        speedTimer--;
        
        if (speedTimer == 0) {
            speed++;
            Greenfoot.setSpeed(speed);
            speedTimer = 200;
        }
    }
}